/****************************************************************************
**
** Copyright (C) 2021 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of Qt Quick Ultralite compatibility.
**
** $QT_BEGIN_LICENSE:GPL$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3 or (at your option) any later version
** approved by the KDE Free Qt Foundation. The licenses are as published by
** the Free Software Foundation and appearing in the file LICENSE.GPL3
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

import QtQuick 2.15
import QtQuick.Window 2.2

//! [Screen compatibility]
Item {
    id: root

    property string outputDevice: "device"
    property alias backgroundColor: wnd.color

    property real defaultApplicationWidth: 0
    property real defaultApplicationHeight: 0

    onChildrenChanged: {
        if (wnd.isAvailable)
            wnd.reparenting()
    }

    Window {
        id: wnd
        visible: true

        width: root.width
        height: root.height

        property bool reparentingBlock: false
        property bool isAvailable: false

        Component.onCompleted: {
            reparenting()
            isAvailable = true
        }

        function reparenting() {
            if (reparentingBlock)
                return;

            reparentingBlock = true;

            var result = [];
            var rootChildren = root.children;
            for (var i = 0; i < rootChildren.length; i++) {
                if (rootChildren[i] !== wnd) {
                    result.push(rootChildren[i]);
                }
            }
            wnd.data = result;

            reparentingBlock = false;
        }
    }
}
//! [Screen compatibility]
