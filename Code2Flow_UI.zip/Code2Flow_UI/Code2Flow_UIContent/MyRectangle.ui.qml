import QtQuick
import QtQuick.Controls

Rectangle {
    id: rectangle
    width: 1920
    height: 1080

    color: Constants.backgroundColor
    states: [
        State {
            name: "clicked"
        }
    ]
}
