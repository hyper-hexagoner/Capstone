import QtQuick
import Code2Flow_UI

Window {
    width: mainScreen.width
    height: mainScreen.height

    visible: true
    title: "Code2Flow_UI"

    Screen01 {
        id: mainScreen

        anchors.centerIn: parent
    }

}

