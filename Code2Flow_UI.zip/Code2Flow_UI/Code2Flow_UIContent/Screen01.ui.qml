

/*
This is a UI file (.ui.qml) that is intended to be edited in Qt Design Studio only.
It is supposed to be strictly declarative and only uses a subset of QML. If you edit
this file manually, you might introduce QML code that is not supported by Qt Design Studio.
Check out https://doc.qt.io/qtcreator/creator-quick-ui-forms.html for details on .ui.qml files.
*/
import QtCore
import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import Code2Flow_UI

Rectangle {
    id: basepage
    width: Constants.width
    height: Constants.height
    color: "#dcdcdc"

    Text {
        id: code2flow
        text: qsTr("Code2Flow")
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.leftMargin: 776
        anchors.rightMargin: 776
        anchors.topMargin: 141
        anchors.bottomMargin: 858
        font.italic: true
        font.pointSize: 72
        font.family: "Arial"
    }

    Button {
        id: lod
        width: 450
        text: qsTr("")
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.topMargin: 549
        anchors.bottomMargin: 425
        font.pointSize: 20
        font.family: "Arial"
        anchors.horizontalCenterOffset: 0
        anchors.horizontalCenter: parent.horizontalCenter

        Connections {
            target: lod
            function onClicked() {
                lodselect.visible = true
            }
        }

        Rectangle {
            id: rectangle2
            x: -11
            y: 5
            width: 471
            height: 97
            color: "#76808d"
            radius: 35

            Text {
                id: text3
                x: 59
                y: 25
                width: 353
                height: 48
                color: "#485a70"
                text: qsTr("Click to select Level of Detail")
                font.pixelSize: 22
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                font.italic: true
            }
        }
    }

    Button {
        id: make
        width: 278
        text: qsTr("")
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.topMargin: 785
        anchors.bottomMargin: 181
        highlighted: false
        flat: false
        icon.color: "#ffffff"
        font.pointSize: 20
        font.family: "Arial"
        Connections {
            target: make
            function onClicked() {
                basepage.state = "MakeGraph"
            }
        }

        Rectangle {
            id: rectangle1
            x: -54
            y: -3
            width: 386
            height: 116
            color: "#003a63"
            radius: 60

            Text {
                id: text2
                x: 79
                y: 35
                width: 229
                height: 44
                color: "#718ba3"
                text: qsTr("Make Chart")
                font.pixelSize: 32
                horizontalAlignment: Text.AlignHCenter
            }
        }
        anchors.horizontalCenterOffset: 0
        anchors.horizontalCenter: parent.horizontalCenter
    }

    Button {
        id: fileup
        x: 659
        width: 602
        text: qsTr("")
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.topMargin: 301
        anchors.bottomMargin: 569
        font.pointSize: 32
        highlighted: false
        flat: true

        Rectangle {
            id: bounds
            color: "#436f91"
            radius: 35
            anchors.fill: parent

            Text {
                id: text1
                x: 183
                y: 81
                width: 237
                height: 48
                color: "#00406e"
                text: qsTr("Click to Upload File")
                font.pixelSize: 30
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignBottom
                font.italic: true
                font.family: "Arial"
            }
        }
    }

    Rectangle {
        id: lodselect
        x: 549
        width: 823
        opacity: 1
        visible: false
        color: "#bfbfbf"
        radius: 45
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.topMargin: 301
        anchors.bottomMargin: 301
        clip: false

        CheckBox {
            id: checkBox
            x: 66
            y: 108
            text: qsTr("Compressed Loops")
            font.pointSize: 20
            font.family: "Arial"
        }

        CheckBox {
            id: checkBox1
            x: 66
            y: 167
            text: qsTr("Compressed Simple Statements")
            font.pointSize: 20
            font.family: "Arial"
        }

        CheckBox {
            id: checkBox2
            x: 66
            y: 226
            text: qsTr("Compressed Function Calls")
            font.pointSize: 20
            font.family: "Arial"
        }

        Button {
            id: close
            x: 366
            y: 386
            text: qsTr("Close")

            Connections {
                target: close
                function onClicked() {
                    lodselect.visible = false
                }
            }
        }
    }

    Button {
        id: back
        visible: false
        text: qsTr("")
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.leftMargin: 117
        anchors.rightMargin: 1634
        anchors.topMargin: 945
        anchors.bottomMargin: 58

        Rectangle {
            id: rectangle
            x: -70
            y: -12
            width: 308
            height: 100
            visible: false
            color: "#616d7c"
            radius: 20

            Text {
                id: text4
                x: 77
                y: 24
                width: 154
                height: 52
                visible: false
                text: qsTr("Back")
                font.pixelSize: 32
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                font.italic: true
                font.family: "Arial"
            }
        }

        Connections {
            target: back
            function onClicked() {
                basepage.state = ""
            }
        }
    }

    Rectangle {
        id: codedis
        x: 385
        y: 49
        width: 697
        height: 983
        visible: false
        color: "#ffffff"

        Text {
            id: text5
            x: 82
            y: 92
            text: qsTr("Text")
            font.pixelSize: 12
        }
    }

    Rectangle {
        id: graphdis
        x: 1105
        y: 49
        width: 783
        height: 983
        visible: false
        color: "#ffffff"
    }

    Button {
        id: download
        x: 114
        y: 263
        width: 176
        height: 84
        visible: false

        Rectangle {
            id: rectangle3
            x: -54
            y: -14
            width: 276
            height: 100
            color: "#002c53"
            radius: 30

            Text {
                id: text6
                x: 66
                y: 23
                width: 145
                height: 55
                color: "#587995"
                text: qsTr("Download Graph")
                font.pixelSize: 24
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                font.family: "Arial"
            }
        }
    }
    states: [
        State {
            name: "MakeGraph"

            PropertyChanges {
                target: code2flow
                visible: true
                text: qsTr("Code2Flow")
                anchors.leftMargin: 27
                anchors.rightMargin: 1544
                anchors.topMargin: 32
                anchors.bottomMargin: 967
                font.pointSize: 66
            }
            PropertyChanges {
                target: lod
                visible: false
            }
            PropertyChanges {
                target: make
                visible: false
            }
            PropertyChanges {
                target: fileup
                visible: false
            }
            PropertyChanges {
                target: back
                visible: true
            }

            PropertyChanges {
                target: rectangle
                visible: true
            }

            PropertyChanges {
                target: text4
                visible: true
            }
            PropertyChanges {
                target: codedis
                visible: true
                color: "#0c0e11"
                radius: 15
            }
            PropertyChanges {
                target: graphdis
                visible: true
                radius: 15
            }
            PropertyChanges {
                target: download
                x: 114
                y: 266
                visible: true
            }

            PropertyChanges {
                target: text5
                x: 82
                y: 92
                width: 533
                height: 799
                color: "#cff2ff"
                text: qsTr(" ")
                font.pixelSize: 24
                font.family: "Arial"
            }
        }
    ]
}
